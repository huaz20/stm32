#ifndef __GTIM_H
#define __GTIM_H

#include "./SYSTEM/sys/sys.h"

void gtim_timx_pwm_chy_init(uint16_t psc,uint16_t arr);

#endif

