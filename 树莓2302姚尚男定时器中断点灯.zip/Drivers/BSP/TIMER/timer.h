#ifndef __TIMER_H
#define __TIMER_H

#include "./SYSTEM/sys/sys.h"

void btim_timx_int_init(uint16_t arr,uint16_t psc);

#endif

