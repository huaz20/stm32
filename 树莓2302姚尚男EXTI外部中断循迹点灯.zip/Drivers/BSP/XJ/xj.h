#ifndef __XJ_H
#define __XJ_H

#include "./SYSTEM/sys/sys.h"

void xj_init(void);
uint8_t xj_scan(void);

#endif

