#ifndef __EXTI_H
#define __EXTI_H

#include "./SYSTEM/sys/sys.h"

void exti_init(void);

#endif

